BoxKit - individual parts (ONE FILE PER PART, for home printing)
3 segments: print STANDING on the end face, no supports.
3 doors + 2 comb sliders: print flat, fluted face down.
PLA, 0.2mm, 3 walls, 15-20% infill. Assembly: see the demo page.
Do NOT also print plate/combo files - they contain these same parts.
